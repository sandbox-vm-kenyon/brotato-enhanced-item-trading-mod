extends CoopShop

func _ready():
	._ready()
	var player_count: int = RunData.get_player_count()

	for player_index in player_count:
		var item_popup = _get_item_popup(player_index)
		item_popup.connect("weapon_trade_button_pressed_coop", self, "on_weapon_trade_button_pressed_coop")
		item_popup.connect("item_trade_button_pressed_coop", self, "on_item_trade_button_pressed_coop")


func on_weapon_trade_button_pressed_coop(weapon_data: WeaponData, from_player_index: int = 0, to_player_index: int = 1) -> void:
	if not _can_weapon_be_traded_eit(weapon_data, to_player_index):
		SoundManager.play(Utils.get_rand_element(Player.new().hurt_sounds), 0, 0.0, true)
		return

	process_player_weapons_inventory(weapon_data, from_player_index)
	_give_weapon_direct(weapon_data, to_player_index)
	SoundManager.play(Utils.get_rand_element(recycle_sounds), 0, 0.1, true)


func on_item_trade_button_pressed_coop(item_data: ItemData, from_player_index: int = 0, to_player_index: int = 1) -> void:
	var no_trade_items = ["item_celery_tea", "item_lure", "item_peacock"]
	if no_trade_items.has(item_data.my_id):
		return

	if not RunData.is_can_trade_item(item_data, to_player_index):
		SoundManager.play(Utils.get_rand_element(Player.new().hurt_sounds), 0, 0.0, true)
		return

	process_player_items_inventory(item_data, from_player_index)
	.buy_item(item_data, to_player_index)
	SoundManager.play(Utils.get_rand_element(recycle_sounds), 0, 0.1, true)


func _can_weapon_be_traded_eit(weapon_data: WeaponData, player_index: int) -> bool:
	var no_melee = RunData.get_player_effect_bool(Keys.no_melee_weapons_hash, player_index)
	var no_ranged = RunData.get_player_effect_bool(Keys.no_ranged_weapons_hash, player_index)
	var no_dupes = RunData.get_player_effect_bool(Keys.no_duplicate_weapons_hash, player_index)
	var lock_current = RunData.get_player_effect_bool(Keys.lock_current_weapons_hash, player_index)

	if no_melee and weapon_data.type == WeaponType.MELEE:
		return false
	if no_ranged and weapon_data.type == WeaponType.RANGED:
		return false
	if no_dupes and weapon_data.weapon_id in RunData.get_unique_weapon_ids(player_index):
		return false

	var free_slots = RunData.get_free_weapon_slots(player_index)
	if free_slots > 0:
		return not lock_current

	if weapon_data.tier > 1:
		for existing in RunData.get_player_weapons(player_index):
			if existing.weapon_id == weapon_data.weapon_id and existing.tier == weapon_data.tier - 1:
				return true

	return false


func _give_weapon_direct(weapon_data: WeaponData, player_index: int) -> void:
	var free_slots = RunData.get_free_weapon_slots(player_index)
	if free_slots > 0:
		RunData.add_weapon(weapon_data, player_index)
	else:
		for existing in RunData.get_player_weapons(player_index):
			if existing.weapon_id == weapon_data.weapon_id and existing.tier == weapon_data.tier - 1:
				RunData.add_weapon(weapon_data, player_index)
				_combine_weapon(existing, player_index, true)
				break

	var gear = _get_gear_container(player_index)
	gear.set_weapons_data(RunData.get_player_weapons(player_index))
	gear.weapons_container.focus_element_index(0)
	_update_stats(player_index)


func process_player_items_inventory(item_data: ItemData, player_index: int):
	_popup_manager.reset_focus(player_index)
	_update_stats(player_index)
	RunData.remove_item(item_data, player_index, false)
	_get_shop_items_container(player_index).reload_shop_items()
	_get_coop_player_container(player_index).on_hide_focused_inventory_popup()
	var player_gear_container = _get_gear_container(player_index)
	player_gear_container.set_items_data(RunData.get_player_items(player_index))
	player_gear_container.items_container.focus_element_index(0)


func process_player_weapons_inventory(weapon_data: WeaponData, player_index: int):
	_popup_manager.reset_focus(player_index)
	_update_stats(player_index)
	RunData.remove_weapon(weapon_data, player_index)
	_get_shop_items_container(player_index).reload_shop_items()
	_get_coop_player_container(player_index).on_hide_focused_inventory_popup()
	var player_gear_container = _get_gear_container(player_index)
	player_gear_container.set_weapons_data(RunData.get_player_weapons(player_index))
	player_gear_container.items_container.focus_element_index(0)
